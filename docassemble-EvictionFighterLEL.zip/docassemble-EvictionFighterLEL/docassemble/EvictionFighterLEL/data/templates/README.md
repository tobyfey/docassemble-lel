# Template directory

If you want to use non-standard document templates with pandoc,
put template files in this directory.
